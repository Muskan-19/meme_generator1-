export default {
    "success": true,
    "data": {
        "memes": [
            {
                "id": "61579",
                "name": "One Does Not Simply",
                "url": "https://i.imgflip.com/1bij.jpg",
                "width": 568,
                "height": 335,
                "box_count": 2
            },
            {
                "id": "101470",
                "name": "Ancient Aliens",
                "url": "https://i.imgflip.com/26am.jpg",
                "width": 500,
                "height": 437,
                "box_count": 2
            },
            {
                "id": "61532",
                "name": "The Most Interesting Man In The World",
                "url": "https://i.imgflip.com/1bh8.jpg",
                "width": 600,
                "height": 600,
                "box_count": 2
            },
            {
                "id": "61544",
                "name": "Success Kid",
                "url": "https://i.imgflip.com/1bhk.jpg",
                "width": 500,
                "height": 500,
                "box_count": 2
            },
            {
                "id": "101287",
                "name": "Expanding Brain",
                "url": "https://i.imgflip.com/1jwh.jpg",
                "width": 600,
                "height": 600,
                "box_count": 4
            },
            {
                "id": "112126428",
                "name": "Distracted Boyfriend",
                "url": "https://i.imgflip.com/1ur9b0.jpg",
                "width": 500,
                "height": 500,
                "box_count": 3
            },
            {
                "id": "131087935",
                "name": "Running Away Balloon",
                "url": "https://i.imgflip.com/261o3j.jpg",
                "width": 500,
                "height": 500,
                "box_count": 5
            },
            {
                "id": "21735",
                "name": "The Rock Driving",
                "url": "https://i.imgflip.com/39t1o.jpg",
                "width": 500,
                "height": 500,
                "box_count": 2
            },
            {
                "id": "123999232",
                "name": "Is This A Pigeon",
                "url": "https://i.imgflip.com/1o00in.jpg",
                "width": 500,
                "height": 500,
                "box_count": 3
            },
            {
                "id": "91538330",
                "name": "X, X Everywhere",
                "url": "https://i.imgflip.com/1ihzfe.jpg",
                "width": 500,
                "height": 500,
                "box_count": 2
            },
            {
                "id": "134797956",
                "name": "American Chopper Argument",
                "url": "https://i.imgflip.com/2896ro.jpg",
                "width": 500,
                "height":500,
                "box_count": 5
            },
            {
                "id": "178591752",
                "name": "Tuxedo Winnie The Pooh",
                "url": "https://i.imgflip.com/2ybua0.jpg",
                "width": 500,
                "height": 500,
                "box_count": 2
            },
            {
                "id": "100777631",
                "name": "Is This A Butterfly",
                "url": "https://i.imgflip.com/1o0c9s.jpg",
                "width": 500,
                "height": 500,
                "box_count": 3
            },
            {
                "id": "438680",
                "name": "Batman Slapping Robin",
                "url": "https://i.imgflip.com/9ehk.jpg",
                "width": 400,
                "height": 387,
                "box_count": 2
            },
            {
                "id": "8072285",
                "name": "Doge",
                "url": "https://i.imgflip.com/4t0m5.jpg",
                "width": 620,
                "height": 620,
                "box_count": 5
            },
            {
                "id": "91545132",
                "name": "Two Buttons",
                "url": "https://i.imgflip.com/1g8my4.jpg",
                "width": 600,
                "height": 908,
                "box_count": 2
            },
            {
                "id": "61556",
                "name": "Grandma Finds The Internet",
                "url": "https://i.imgflip.com/1bhw.jpg",
                "width": 640,
                "height": 480,
                "box_count": 2
            },
            {
                "id": "29562797",
                "name": "I'm The Captain Now",
                "url": "https://i.imgflip.com/5c7c.jpg",
                "width": 480,
                "height": 280,
                "box_count": 2
            },
            {
                "id": "84341851",
                "name": "Evil Kermit",
                "url": "https://i.imgflip.com/1e7ql7.jpg",
                "width": 700,
                "height": 325,
                "box_count": 2
            },
            {
                "id": "40945639",
                "name": "Drake Hotline Bling",
                "url": "https://i.imgflip.com/30b1gx.jpg",
                "width": 1200,
                "height": 1200,
                "box_count": 2
            }
        ]
    }
};
