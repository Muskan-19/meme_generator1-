import React, { useState, useEffect } from "react";
import "./style.css";

export default function Form() {
    const [meme, setMeme] = useState({
        topText: "",
        bottomText: "",
        randomImage: ""
    });

    const [allMemeImages, setAllMemeImages] = useState([]);

    useEffect(() => {
        async function fetchMemes() {
            try {
                const response = await fetch("https://api.imgflip.com/get_memes");
                const data = await response.json();
                setAllMemeImages(data.data.memes);
            } catch (error) {
                console.error("Error fetching memes:", error);
            }
        }
        fetchMemes();
    }, []);

    function getMemeImage(event) {
        event.preventDefault();

        if (allMemeImages.length === 0) {
            console.error("No memes found");
            return;
        }

        const randomNumber = Math.floor(Math.random() * allMemeImages.length);
        const { url } = allMemeImages[randomNumber];
        setMeme({
            topText: "",
            bottomText: "",
            randomImage: url
        });
    }

    function handleChange(event) {
        const { name, value } = event.target;
        setMeme(prevMeme => ({
            ...prevMeme,
            [name]: value
        }));
    }

    return (
        <main className="main">
            <form className="form">
                <input 
                    type="text" 
                    className="input1" 
                    placeholder="Top text" 
                    name="topText" 
                    value={meme.topText}
                    onChange={handleChange}
                />
                <input 
                    type="text" 
                    className="input1" 
                    placeholder="Bottom text" 
                    name="bottomText" 
                    value={meme.bottomText}
                    onChange={handleChange}
                />
                <button className="button1" onClick={getMemeImage}>
                    Get a new meme image
                </button>
            </form>
            <div className="meme">
                <img src={meme.randomImage} alt="Random Meme" className="meme-image" />
                <h2 className="meme-text top">{meme.topText}</h2>
                <h2 className="meme-text bottom">{meme.bottomText}</h2>
            </div>
        </main>
    );
}
