import React from 'react';
import shregImage from './shreg.png';  
import './style.css';  
export default function Header() {
  return (
    <div>
      <header className='header'>
        
        <img
          src={shregImage}
          alt="shreg hai"
          style={{ width: '70px', height: '70px' }} 
          className='header-img' 
        />
        <h2 className='header-title'>meme Generator</h2>
        
        <h4>ReactCourse-Project3</h4>
      </header>
    </div>
  );
}
